package com.example.latihanstorage;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;



public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button external, internal;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        external = (Button) findViewById(R.id.buttonExternalStorage);
        internal = (Button) findViewById(R.id.buttonInternalStorage);
        external.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openInternalActivity();
            }
        });

        internal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openExternalActivity();
            }
        });

    }
    public void openInternalActivity(){
        Intent intent = new Intent(this, InternalActivity.class);
        startActivity(intent);
    }
    public void openExternalActivity(){
        Intent intent = new Intent(this, ExternalActivity.class);
        startActivity(intent);
    }


    @Override
    public void onClick(View v) {

    }
}